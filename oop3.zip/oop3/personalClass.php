<?php 

class Person {
	public $firstName;
	public $lastName;
	public $age;
	private $address;
	public $my_salary;

	function printInfo(){
		$result ='';
		$result .= $this->firstName .', '.$this->lastName;
		$result .= ', '.$this->age .', ' . $this->address;
		return $result;
	}

}

$person1 = new Person();

echo '<pre>';
echo var_dump($person1);
echo '</pre>';
echo "------------------------------";

$person1-> firstName='Haneen';
$person1-> lastName='Zayed';
$person1-> age = 23;
$person1-> address = 'Amman - Jordan';
$person1-> my_salary= 1554;

echo '<pre>';
echo var_dump($person1);
echo '</pre>';
echo "------------------------------";
echo '<br/>';

echo $person1->printInfo();

?>
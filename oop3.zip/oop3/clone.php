<?php

class Employee {
	private $firstName;
	private $lastName;
	private $age;
	private $address;
	private $my_salary;


public function __construct($firstName, $lastName, $age, $address, $my_salary){

		$this->firstName=$firstName;
		$this->lastName=$lastName;
		$this->age=$age;
		$this->address=$address;
		$this->my_salary=$my_salary;
}

public function __toString(){
		return "firstName: $this->firstName <br> lastName: $this->lastName  <br> age: $this->age <br>  address: $this->address <br> my_salary:$this->my_salary ";
	}

}

$emp= new Employee('Haneen', 'Hazem', 23, 'Jermany', 14563);
echo $emp . '<br>' .'------------------------'.'<br> <br> <br>';

$emp1= new Employee('Layan', 'bannana', 18, 'Amman', 2034);
echo $emp1 . '<br>' .'------------------------'.'<br> <br> <br>';

$copy1 = $emp;
echo "$copy1". '<br>' .'------------------------'.'<br> <br> <br>';

$copy2= clone $emp1;
echo "$copy2". '<br>' .'------------------------'.'<br> <br> <br>';
?>
<?php 

class Employee {
	private $firstName;
	private $lastName;
	private $age;
	private $address;
	private $my_salary;

	public function getFirstName(){
		return $this->firstName; 
	}
	public function getLastName(){
		return $this->lastName; 
	}
	public function getAge(){
		return $this->age; 
	}
	public function getAddress(){
		return $this->address; 
	}
	public function getMy_salary(){
		return $this->my_salary; 
	}

	public function setFirstName($firstName){
		$this->$firstName=$firstName;
	}
	public function setLastName($lastName){
		$this->$lastName=$lastName;
	}
	public function setAge($age){
		$this->$age=$age;
	}
	public function setAddress($address){
		$this->$address=$address;
	}
	public function setMy_salary($my_salary){
		$this->$my_salary=$my_salary;
	}


}

$person1 = new Employee();

echo '<pre>';
echo var_dump($person1);
echo '</pre>';
echo "------------------------------";

$person1-> setFirstName('Haneen');
$person1-> setLastName('Zayed');
$person1-> setAge(23);
$person1-> setAddress('Amman - Jordan');
$person1-> setMy_salary(1578);

echo '<pre>';
echo print_r($person1);
echo '</pre>';
echo "------------------------------";

?>
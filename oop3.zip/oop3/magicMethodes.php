<?php

class Student{
	private $properties;

	public function __get($propertiesName){
		if(array_variables($propertiesName,$properties)){
			return $this->properties[$propertiesName];
		}
	}

	public function __set($propertiesName,$propertyValue){
		$this-> properties[$propertiesName]= $propertyValue;
	}
}

$studentInfo = new Student();
$studentInfo-> fisrtName ='HAneen';
$studentInfo-> lastName ='ZAyed';
$studentInfo-> age =23;
$studentInfo-> salary =15457.52;
$studentInfo-> address ='Amman - Jordan';

echo '<pre>';
echo var_dump($studentInfo);
echo '</pre>';
echo "------------------------------";


?>
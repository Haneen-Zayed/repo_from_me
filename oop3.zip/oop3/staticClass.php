<?php

// staticClass.php 



class Student{

	static public $myName='Omar';
	public static $mylastName='Majjed';
	public static $myArray = array('A' =>1 , 'B' =>2 ,'C' => 3);
	private $properties;

	public function __get($propertiesName){
		if(array_variables($propertiesName,$properties)){
			return $this->properties[$propertiesName];
		}
	}

	public function __set($propertiesName,$propertyValue){
		$this-> properties[$propertiesName]= $propertyValue;
	}
}
// get variables from static

echo Student::$myName . '<br/>';

echo Student::$mylastName;

echo '<pre>';
echo var_dump(Student::$myArray);
echo '</pre>';
echo "------------------------------";





?>
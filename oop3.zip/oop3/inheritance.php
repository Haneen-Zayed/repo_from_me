<?php 
//inheritance.php 

class Person{


	public function printFirstName($name){ echo 'Name is :'.$name;}
	public function printLastName($lname){echo 'Last Name is :'.$lname;}
	public function printAge($age){echo 'Age is :'.$age;}

}

class Student extends Person{

	public function printFirstName($name){ echo 'Name is :'.$name;}
}

class Employee extends Person{

	public function printLastName($lname){echo 'Last Name is :'.$lname;}
	public function printAddress($address){echo 'Address is :'.$address;}
}

class Haneen extends Employee{

	public function printLastName($lname){echo 'Last Name is :'.$lname;}
	public function printAddress($address){echo 'Address is :'.$address;}
}

$Student =new Student();
$Student->printFirstName('Class Haneen');
echo "<br>";
echo "<br>";

$employee =new Employee();
$employee->printLastName('Class Employee');
echo "<br>";
$employee->printAddress('Amman - Jordan');
echo "<br>";
echo "<br>";

$haneen = new Haneen();
$haneen->printLastName('Class Haneen');
echo "<br>";
$haneen->printAddress('Irbid - Jordan');
echo "<br>";
?>

<?php
//abstraction.php 

abstract class Person{

	protected $firstName;
	protected $lastName;

	public function __construct($firstName,$lastName){

		$this->firstName=$firstName;
		$this->lastName=$lastName;
	}

	public function __toString(){

		return $this->firstName.' '.$this->lastName;
	}

	abstract public function getAge();
	abstract public function getSalary();
}

class Employee extends Person{

	private $salary;
	private $age;

	public function __construct($firstName,$lastName,$salary,$age ){

		parent::__construct($firstName,$lastName); 

		$this->salary=$salary;
		$this->age=$age;
	}
	// you have to use one abstracted Method at least when you inherite from abstracted class 

	 public function getAge(){}
	 public function getSalary(){}

	public function __toString(){

		return sprintf("Employee Info Full name : %s   ,Salary : %0.3f ,age : %d ", parent::__toString(),$this->salary, $this->age);
	}
}


$employee = new Employee('Haneen', 'Zayed', 3000,23);
echo $employee;

class Student extends Person{

	private $department;
	private $age;
	private $address;

	public function __construct($firstName,$lastName,$department,$address,$age){

		parent::__construct($firstName,$lastName); 

		$this->age=$age;
		$this->department=$department;
		$this->address=$address;
	}

	public function getAge(){

		return $this->age;
	}
	public function getDepartment(){

		return $this->department;
	}
	public function getAddress(){

		return $this->address;
	}
	public function getSalary(){}
	
public function __toString(){

		return sprintf("Employee Info Full name : %s   ,Department : %s ,age : %d  ,Address : %s ", parent::__toString(),$this->department , $this->age,$this->getAddress() );
		//you can use get function instead properties
	}

}

echo "<br> <br> <br>";


$student = new Student('Haneen', 'Zayed', 'department', 'Amman - jorden', 23);
echo $student;



?>
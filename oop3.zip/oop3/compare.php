
<?php

class Employee {
	private $firstName;
	private $lastName;
	private $age;
	private $address;
	private $my_salary;


public function __construct($firstName, $lastName, $age, $address, $my_salary){

		$this->firstName=$firstName;
		$this->lastName=$lastName;
		$this->age=$age;
		$this->address=$address;
		$this->my_salary=$my_salary;
}

public static function compare($obj1, $obj2){
	return $obj2 == $obj1;
}

public function __toString(){
		return "firstName: $this->firstName <br> lastName: $this->lastName  <br> age: $this->age <br>  address: $this->address <br> my_salary:$this->my_salary ";
	}

}

$emp= new Employee('Haneen', 'Hazem', 23, 'Jermany', 14563);
$emp1= new Employee('Haneen', 'Hazem', 23, 'Jermany', 14563);

if (Employee::compare($emp1,$emp)){
	echo 'they are equal';
}
else {
	echo 'thiey are not equal';
}
echo '<br>';
$emp1 = $emp;
if ( $emp1 === $emp ){
	echo 'they are equal';
}
else {
	echo 'they are not equal';
}
?>